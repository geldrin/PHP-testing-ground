<?php

$config = array(
  'siteid'          => 'kpmg',
  'node_sourceip'   => 'vsq-conv.kpmg.hu',
  'node_role'       => 'converter',
  'baseuri'         => 'video.kpmg.hu/',
  'staticuri'       => 'vsq-static.kpmg.hu/',
  'adminuri'        => 'video.kpmg.hu/a2143/',
  'cookiedomain'    => '.kpmg.hu',
  'logemails' => array(
//    'devhiba@videosqr.com',
  ),
  'database' => array(
    'type'     => 'mysql',
    'host'     => 'vsq-stream.kpmg.hu',
    'username' => 'videosquare',
    'password' => 'gGAGeGdVNvvE',
    'database' => 'videosquare',
    'reconnectonbusy' => true,
    'maxretries' => 30,
  ),

  // Upload
  'uploadpath'     => '/srv/upload/videosquare.eu/',
  'useravatarpath' => '/srv/upload/videosquare.eu/useravatars/',
  // Conv temp
  'convpath'       => '/srv/vsq_temp/videosquare.eu/converter/',

  // Converter related settings
  'ffmpeg_alt'            => '/home/conv/ffmpeg/ffmpeg-customVSQ-git20160628-static/ffmpeg',
  'ffmpegthumbnailer'     => '/usr/bin/ffmpegthumbnailer',
  'video_max_res'         => '4096x4096',
  'ocr_alt'               => '/usr/bin/cuneiform',
  'ocr_frame_distance'     => 1.0,         // Desired distance between frames (in seconds)
  'ocr_threshold'          => 0.010,       // Max. difference between ocr frames

  'organizationfallbackurl' => 'http://video.kpmg.hu',

  'fallbackstreamingserver' => array(
    'server' => 'vsq-stream.kpmg.hu',
    'type'   => 'wowza',
  ),

  'setupdirs' => array(
    'user'            => 'conv', // a user/group amire chown -R eljuk az egesz konyvtarat
    'group'           => 'vsq',
    'perms'           => 'g+w', // a chmod -R parametere
    'privilegeduser'  => 'www-data', // a gitignorebol vett konyvtarak user/group/permje
    'privilegedgroup' => 'www-data',
    'extradirs'       => array(
      array(
        'dir'  => $this->basepath . 'httpdocs/flash',
        'user' => 'conv',
      ),
      array(
        'dir'   => $this->basepath . 'data',
        'perms' => 'a+w',
      ),
      array(
        'dir'   => $this->basepath . 'modules/Locale',
        'perms' => 'a+w',
      ),
      array(
        'dir'   => $this->basepath . 'modules/**/**/Locale',
        'perms' => 'a+w',
      ),
    ),
  ),

  // SSH
  'ssh_key'         => '/home/conv/.ssh/id_dsa',
  'ssh_pubkey'      => '/home/conv/.ssh/id_dsa.pub',

  // Debug
  'logtoconsole' => false,

);

// Job configuration template for frontend and converter nodes
$config['jobs'] = array(
  'converter' => array(
    'job_system_health'  => array(
      'enabled'             => true,
      'watchdogtimeoutsecs' => 5 * 60,
      'supresswarnings'     => false
    ),
    'job_media_convert2' => array(
      'enabled'             => true,
      'watchdogtimeoutsecs' => 15 * 60,
      'supresswarnings'     => false
    ),
    'job_live_thumbnail' => array(
      'enabled'             => false,
      'watchdogtimeoutsecs' => 15 * 60,
      'supresswarnings'     => true,
      'debug_mode'          => false,
    ),
    'job_ocr'            => array(
      'enabled'             => true,
      'watchdogtimeoutsecs' => 15 * 60,
      'supresswarnings'     => false
    ),
    'job_document_index' => array(
      'enabled'             => true,
      'watchdogtimeoutsecs' => 5 * 60,
      'supresswarnings'     => false
    ),
    'job_vcr_control'    => array(
      'enabled'             => true,
      'watchdogtimeoutsecs' => 15 * 60,
      'supresswarnings'     => false
    )
  )
);

return $config;
